package org.bouncycastle.asn1.x509;

import org.bouncycastle.asn1.ASN1BitString;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1Integer;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERSequence;

public class AttributeCertificateInfo
    extends ASN1Object
{
    private ASN1Integer             version;
    private Holder                  holder;
    private AttCertIssuer           issuer;
    private AlgorithmIdentifier     signature;
    private ASN1Integer             serialNumber;
    private AttCertValidityPeriod   attrCertValidityPeriod;
    private ASN1Sequence            attributes;
    private ASN1BitString           issuerUniqueID;
    private Extensions              extensions;

    public static AttributeCertificateInfo getInstance(
        ASN1TaggedObject obj,
        boolean          explicit)
    {
        return getInstance(ASN1Sequence.getInstance(obj, explicit));
    }

    public static AttributeCertificateInfo getInstance(
        Object  obj)
    {
        if (obj instanceof AttributeCertificateInfo)
        {
            return (AttributeCertificateInfo)obj;
        }
        else if (obj != null)
        {
            return new AttributeCertificateInfo(ASN1Sequence.getInstance(obj));
        }

        return null;
    }

    private AttributeCertificateInfo(
        ASN1Sequence   seq)
    {
        if (seq.size() < 6 || seq.size() > 9)
        {
            throw new IllegalArgumentException("Bad sequence size: " + seq.size());
        }

        int start;
        if (seq.getObjectAt(0) instanceof ASN1Integer)   // in version 1 certs version is DEFAULT  v1(0)
        {
            this.version = ASN1Integer.getInstance(seq.getObjectAt(0));
            start = 1;
        }
        else
        {
            this.version = ASN1Integer.ZERO;
            start = 0;
        }

        this.holder = Holder.getInstance(seq.getObjectAt(start));
        this.issuer = AttCertIssuer.getInstance(seq.getObjectAt(start + 1));
        // RFC 3281 sec. 4.2.3: the attribute certificate issuer MUST identify
        // the issuer; an empty AttCertIssuer is not a valid identifier.
        if (isEmptyIssuer(this.issuer))
        {
            throw new IllegalArgumentException("attribute certificate issuer is empty");
        }
        this.signature = AlgorithmIdentifier.getInstance(seq.getObjectAt(start + 2));
        this.serialNumber = ASN1Integer.getInstance(seq.getObjectAt(start + 3));
        this.attrCertValidityPeriod = AttCertValidityPeriod.getInstance(seq.getObjectAt(start + 4));
        this.attributes = ASN1Sequence.getInstance(seq.getObjectAt(start + 5));
        
        for (int i = start + 6; i < seq.size(); i++)
        {
            ASN1Encodable    obj = seq.getObjectAt(i);

            if (obj instanceof ASN1BitString)
            {
                this.issuerUniqueID = ASN1BitString.getInstance(seq.getObjectAt(i));
            }
            else if (obj instanceof ASN1Sequence || obj instanceof Extensions)
            {
                this.extensions = Extensions.getInstance(seq.getObjectAt(i));
            }
        }
    }
    
    public ASN1Integer getVersion()
    {
        return version;
    }

    public Holder getHolder()
    {
        return holder;
    }

    public AttCertIssuer getIssuer()
    {
        return issuer;
    }

    public AlgorithmIdentifier getSignature()
    {
        return signature;
    }

    public ASN1Integer getSerialNumber()
    {
        return serialNumber;
    }

    public AttCertValidityPeriod getAttrCertValidityPeriod()
    {
        return attrCertValidityPeriod;
    }

    public ASN1Sequence getAttributes()
    {
        return attributes;
    }

    public ASN1BitString getIssuerUniqueID()
    {
        return issuerUniqueID;
    }

    public Extensions getExtensions()
    {
        return extensions;
    }

    /**
     * Return true when the AttCertIssuer carries no identifying information:
     * an empty v1 GeneralNames sequence, or a v2 V2Form whose issuerName,
     * baseCertificateID and objectDigestInfo are all absent (or whose
     * issuerName, when present, is itself empty).
     */
    static boolean isEmptyIssuer(AttCertIssuer issuer)
    {
        ASN1Encodable inner = issuer.getIssuer();
        if (inner instanceof GeneralNames)
        {
            return ((GeneralNames)inner).getNames().length == 0;
        }
        if (inner instanceof V2Form)
        {
            V2Form v2 = (V2Form)inner;
            GeneralNames issuerName = v2.getIssuerName();
            if (issuerName != null)
            {
                return issuerName.getNames().length == 0;
            }
            return v2.getBaseCertificateID() == null && v2.getObjectDigestInfo() == null;
        }
        return false;
    }

    /**
     * Produce an object suitable for an ASN1OutputStream.
     * <pre>
     *  AttributeCertificateInfo ::= SEQUENCE {
     *       version              AttCertVersion -- version is v2,
     *       holder               Holder,
     *       issuer               AttCertIssuer,
     *       signature            AlgorithmIdentifier,
     *       serialNumber         CertificateSerialNumber,
     *       attrCertValidityPeriod   AttCertValidityPeriod,
     *       attributes           SEQUENCE OF Attribute,
     *       issuerUniqueID       UniqueIdentifier OPTIONAL,
     *       extensions           Extensions OPTIONAL
     *  }
     *
     *  AttCertVersion ::= INTEGER { v2(1) }
     * </pre>
     */
    public ASN1Primitive toASN1Primitive()
    {
        ASN1EncodableVector v = new ASN1EncodableVector(9);

        if (!version.hasValue(0))
        {
            v.add(version);
        }
        v.add(holder);
        v.add(issuer);
        v.add(signature);
        v.add(serialNumber);
        v.add(attrCertValidityPeriod);
        v.add(attributes);
        
        if (issuerUniqueID != null)
        {
            v.add(issuerUniqueID);
        }
        
        if (extensions != null)
        {
            v.add(extensions);
        }
        
        return new DERSequence(v);
    }
}
